/* radare - LGPL - Copyright 2014-2020 - pancake, thestr4ng3r */

#include <r_anal.h>

HEAPTYPE (ut64);

static void labels_kv_free(HtUPKv *kv) {
	if (kv) {
		free (kv->value);
	}
}

static void label_addrs_kv_free(HtPPKv *kv) {
	if (kv) {
		free (kv->key);
		free (kv->value);
	}
}

R_API ut64 r_anal_function_get_label(RAnalFunction *fcn, const char *name) {
	R_RETURN_VAL_IF_FAIL (fcn, UT64_MAX);
	ut64 *addr = ht_pp_find (fcn->label_addrs, name, NULL);
	return addr? *addr: UT64_MAX;
}

R_API const char *r_anal_function_get_label_at(RAnalFunction *fcn, ut64 addr) {
	R_RETURN_VAL_IF_FAIL (fcn, NULL);
	return ht_up_find (fcn->labels, addr, NULL);
}

R_API bool r_anal_function_set_label(RAnalFunction *fcn, const char *name, ut64 addr) {
	R_RETURN_VAL_IF_FAIL (fcn && name, false);
	if (ht_pp_find (fcn->label_addrs, name, NULL)) {
		return false;
	}
	if (!fcn->labels) {
		fcn->labels = ht_up_new (NULL, labels_kv_free, NULL);
	}
	if (!fcn->label_addrs) {
		fcn->label_addrs = ht_pp_new (NULL, label_addrs_kv_free, NULL);
	}
	char *n = strdup (name);
	if (!ht_up_insert (fcn->labels, addr, n)) {
		free (n);
		return false;
	}
	ht_pp_insert (fcn->label_addrs, name, ut64_new (addr));
	return true;
}

R_API bool r_anal_function_delete_label(RAnalFunction *fcn, const char *name) {
	R_RETURN_VAL_IF_FAIL (fcn && name, false);
	ut64 *addr = ht_pp_find (fcn->label_addrs, name, NULL);
	if (!addr) {
		return false;
	}
	ht_up_delete (fcn->labels, *addr);
	ht_pp_delete (fcn->label_addrs, name);
	return true;
}

R_API bool r_anal_function_delete_label_at(RAnalFunction *fcn, ut64 addr) {
	R_RETURN_VAL_IF_FAIL (fcn, false);
	char *name = ht_up_find (fcn->labels, addr, NULL);
	if (!name) {
		return false;
	}
	ht_pp_delete (fcn->label_addrs, name);
	ht_up_delete (fcn->labels, addr);
	return true;
}
