# Statically link the r2ghidra core plugin (and the ghidra-native
# decompiler) into libr_core. This file is included from
# libr/core/Makefile via STATIC_CORE_PLUGINS, so it runs with
# radare2/libr/core as the working directory.
#
# Run 'make -C $(R2GHIDRA_XPS_WD)/r2plugin prepare' once to fetch the
# ghidra-native and zlib subprojects and generate config.h.

R2GHIDRA_XPS_WD=$(LIBR)/xps/p/r2ghidra
R2GHIDRA_XPS_DEC=$(R2GHIDRA_XPS_WD)/subprojects/ghidra-native/src/decompiler
R2GHIDRA_XPS_ZLIB=$(R2GHIDRA_XPS_WD)/subprojects/zlib
R2GHIDRA_XPS_OBD=$(R2GHIDRA_XPS_WD)/r2plugin/obj

ifeq ($(filter clean mrproper,$(MAKECMDGOALS)),)
ifeq ($(wildcard $(R2GHIDRA_XPS_DEC)/marshal.cc),)
$(error r2ghidra: ghidra-native sources not found. Run: make -C $(R2GHIDRA_XPS_WD)/r2plugin prepare)
endif
endif

R2GHIDRA_XPS_CXX_SRCS=\
	R2Architecture.cpp \
	PcodeFixupPreprocessor.cpp \
	R2LoadImage.cpp \
	R2Scope.cpp \
	R2TypeFactory.cpp \
	R2CommentDatabase.cpp \
	CodeXMLParse.cpp \
	ArchMap.cpp \
	R2PrintC.cpp \
	RCoreMutex.cpp \
	r2harvest.cpp \
	SleighAnalValue.cpp \
	SleighAsm.cpp \
	SleighInstruction.cpp \
	anal_ghidra.cpp \
	core_ghidra.cpp

R2GHIDRA_XPS_C_SRCS=\
	anal_ghidra_plugin.c \
	core_ghidra_plugin.c

-include $(R2GHIDRA_XPS_WD)/subprojects/ghidra-native/sources.mk
R2GHIDRA_XPS_DEC_SRCS=$(GHIDRA_EMBEDDED_SRCS)

R2GHIDRA_XPS_ZLIB_SRCS=\
	adler32.c compress.c crc32.c deflate.c gzclose.c gzlib.c \
	gzread.c gzwrite.c infback.c inffast.c inflate.c inftrees.c \
	trees.c uncompr.c zutil.c

R2GHIDRA_XPS_OBJS=$(addprefix $(R2GHIDRA_XPS_OBD)/src_,$(R2GHIDRA_XPS_CXX_SRCS:.cpp=.o))
R2GHIDRA_XPS_OBJS+=$(addprefix $(R2GHIDRA_XPS_OBD)/src_,$(R2GHIDRA_XPS_C_SRCS:.c=.o))
R2GHIDRA_XPS_OBJS+=$(addprefix $(R2GHIDRA_XPS_OBD)/dec_,$(R2GHIDRA_XPS_DEC_SRCS:.cc=.o))
R2GHIDRA_XPS_OBJS+=$(addprefix $(R2GHIDRA_XPS_OBD)/z_,$(R2GHIDRA_XPS_ZLIB_SRCS:.c=.o))

EXTERNAL_STATIC_OBJS+=$(R2GHIDRA_XPS_OBJS)

ifeq ($(shell uname),Darwin)
LDFLAGS+=-lc++
else
LDFLAGS+=-lstdc++ -lm
endif

R2GHIDRA_XPS_CFLAGS=-I$(R2GHIDRA_XPS_WD)/src -I$(R2GHIDRA_XPS_DEC) -I$(R2GHIDRA_XPS_ZLIB)
R2GHIDRA_XPS_CFLAGS+=-DNDEBUG -fPIC -fvisibility=hidden -w
ifeq ($(COMPILER),wasi)
# inside the wasmer sandbox the sleigh files are preopened at /sleigh
R2GHIDRA_XPS_CFLAGS+=-DR2GHIDRA_SLEIGHHOME_DEFAULT=\"/sleigh\"
# radare2's wasi build already bundles a minimal zlib (otezip) whose inflate
# cannot resume across streamed input chunks as ghidra requires; carry a real
# zlib but prefix its symbols (zconf.h Z_PREFIX) so the two never clash.
R2GHIDRA_XPS_CFLAGS+=-DZ_PREFIX
endif
R2GHIDRA_XPS_CXXFLAGS=$(R2GHIDRA_XPS_CFLAGS) -std=c++20

$(R2GHIDRA_XPS_OBD)/src_%.o: $(R2GHIDRA_XPS_WD)/src/%.cpp
	@mkdir -p $(dir $@)
	$(CXX) -c $(CFLAGS) $(R2GHIDRA_XPS_CXXFLAGS) -o $@ $<

$(R2GHIDRA_XPS_OBD)/src_%.o: $(R2GHIDRA_XPS_WD)/src/%.c
	@mkdir -p $(dir $@)
	$(CC) -c $(CFLAGS) $(R2GHIDRA_XPS_CFLAGS) -o $@ $<

$(R2GHIDRA_XPS_OBD)/dec_%.o: $(R2GHIDRA_XPS_DEC)/%.cc
	@mkdir -p $(dir $@)
	$(CXX) -c $(CFLAGS) $(R2GHIDRA_XPS_CXXFLAGS) -o $@ $<

$(R2GHIDRA_XPS_OBD)/z_%.o: $(R2GHIDRA_XPS_ZLIB)/%.c
	@mkdir -p $(dir $@)
	$(CC) -c $(CFLAGS) $(R2GHIDRA_XPS_CFLAGS) -o $@ $<

$(R2GHIDRA_XPS_WD)/config.h: $(R2GHIDRA_XPS_WD)/config.h.acr
	$(MAKE) -C $(R2GHIDRA_XPS_WD)/r2plugin ../config.h

$(R2GHIDRA_XPS_OBD)/src_core_ghidra_plugin.o: $(R2GHIDRA_XPS_WD)/config.h

$(addprefix $(R2GHIDRA_XPS_OBD)/src_,$(R2GHIDRA_XPS_CXX_SRCS:.cpp=.o)): $(wildcard $(R2GHIDRA_XPS_WD)/src/*.h)
