// SPDX-FileCopyrightText: 2020-2026 pancake
// SPDX-License-Identifier: LGPL-3.0-only

// r2 >= 6.2.6 (ABI 174) exposes struct sigaction in r_core_priv.h, hidden by strict -std=c11
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <r_lib.h>
#include <r_anal.h>
#include <r_arch.h>

extern int archinfo(RArchSession *as, ut32 query);
extern bool sanal_init(RArchSession *as);
extern bool sanal_fini(RArchSession *as);
extern RList *r2ghidra_preludes(RArchSession *as);
extern int archinfo(RArchSession *as, ut32 query);
extern char *r2ghidra_regs(RArchSession *as);
#if R2_ABIVERSION >= 109
extern bool r2ghidra_esilcb(RArchSession *as, REsil *esil, RArchEsilAction action);
#else
extern bool r2ghidra_esilcb(RArchSession *as, RArchEsilAction action);
#endif
extern char *get_reg_profile(RAnal *anal);
bool sleigh_decode(RArchSession *as, RAnalOp *op, RArchDecodeMask mask);

RArchPlugin r_arch_plugin_ghidra = {
	.meta = {
		.name = "r2ghidra",
		.desc = "SLEIGH Disassembler from Ghidra",
		.license = "LGPL-3.0-only",
		.author = "FXTi, pancake",
		.version = R2_VERSION,
	},
	.arch = "sleigh",
	.endian = R_SYS_ENDIAN_LITTLE | R_SYS_ENDIAN_BIG,
	.cpus = NULL, // ArchMap resolves r2 aliases and installed Sleigh IDs.
	.bits = 0,
	.init = &sanal_init,
	.fini = &sanal_fini,
	.info = &archinfo,
	.preludes = r2ghidra_preludes,
	.decode = &sleigh_decode,
	.regs = &r2ghidra_regs,
	.esilcb = r2ghidra_esilcb,
	.mnemonics = NULL,
};
